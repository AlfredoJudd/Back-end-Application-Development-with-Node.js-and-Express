<!-- Step 1 to start the app -->
<!-- Open Terminal to final_project directory -->
npm install init -y
npm install axios express express-session jsonwebtoken nodemon

<!-- Step 2 start the app -->
<!-- Open Terimnal to final_project directory -->
node index <!-- or  --> node index.js